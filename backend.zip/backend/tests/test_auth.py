import pytest

@pytest.mark.asyncio
async def test_login_fail(client):
    payload = {
        "username": "wrong",
        "password": "wrong"
    }
    resp = await client.post("/auth/login", json=payload)
    assert resp.status_code in (400, 401)


@pytest.mark.asyncio
async def test_no_auth_access(client):
    resp = await client.get("/lot/list")
    assert resp.status_code in (401, 403)
