import asyncio
import pytest
from httpx import AsyncClient
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

# 匯入你的 FastAPI 主 app
from app.main import app as fastapi_app

# 匯入 SQLAlchemy Base
from app.models.base import Base


# ----------------------------------------
# 建立測試用 SQLite (Async)
# ----------------------------------------
DATABASE_URL = "sqlite+aiosqlite:///:memory:"

engine_test = create_async_engine(
    DATABASE_URL, echo=False, future=True
)

async_session_maker = sessionmaker(
    engine_test,
    expire_on_commit=False,
    class_=AsyncSession,
)


# ----------------------------------------
# Override get_db (FastAPI DI)
# ----------------------------------------
async def override_get_db():
    async with async_session_maker() as session:
        yield session


# ----------------------------------------
# Fixture：建立資料庫 Schema
# ----------------------------------------
@pytest.fixture(scope="session", autouse=True)
async def prepare_database():
    async with engine_test.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine_test.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


# ----------------------------------------
# Fixture：建立測試用 client
# ----------------------------------------
@pytest.fixture
async def client():
    # 覆寫 FastAPI 依賴
    from app.database.database import get_session
    fastapi_app.dependency_overrides[get_session] = override_get_db

    # Mock Redis
    from app.services.redis_client import redis_cache
    redis_cache.flushall = lambda: None
    redis_cache.get = lambda *a, **k: None
    redis_cache.set = lambda *a, **k: None

    # Mock Mongo
    from app.database.mongo import mongo_db
    fastapi_app.dependency_overrides[mongo_db] = lambda: None

    async with AsyncClient(app=fastapi_app, base_url="http://test") as ac:
        yield ac
